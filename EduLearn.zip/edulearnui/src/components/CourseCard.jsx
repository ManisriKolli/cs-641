import React from 'react';

function CourseCard() {
  return (
    <div> Course Card</div>
  );
}

export default CourseCard;