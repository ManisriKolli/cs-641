import React from 'react';

function QuizForm() {
  return (
    <div> Quiz</div>
  );
}

export default QuizForm;