import React from 'react';

function ProfileForm() {
  return (
    <div>ProfileForm </div>
  );
}

export default ProfileForm;