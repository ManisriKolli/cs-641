import React from 'react';

function AdminPanel() {
  return (
    <div> Admin</div>
  );
}

export default AdminPanel;